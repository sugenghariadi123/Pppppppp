package com.satpam.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Layar kunci saat aplikasi melewati batas pemakaian. */
class LockActivity : AppCompatActivity() {

    private val h = Handler(Looper.getMainLooper())
    private var until = 0L
    private var app = ""

    private val tick = object : Runnable {
        override fun run() {
            val left = until - System.currentTimeMillis()
            if (left <= 0) {
                findViewById<TextView>(R.id.txtMsg).text = "Kunci sudah habis. Kamu bisa membuka aplikasi lagi."
                findViewById<TextView>(R.id.txtCount).text = "✓"
                findViewById<Button>(R.id.btnOk).text = "Tutup"
                return
            }
            val s = (left / 1000).toInt()
            findViewById<TextView>(R.id.txtCount).text =
                "%02d:%02d".format(s / 3600, (s % 3600) / 60) + ":" + "%02d".format(s % 60)
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)
        app = intent.getStringExtra("app") ?: "Aplikasi"
        until = intent.getLongExtra("until", 0L)

        findViewById<TextView>(R.id.txtTitle).text = "⛔ $app dikunci Satpam"
        findViewById<TextView>(R.id.txtMsg).text =
            "Batas main habis. Buka lagi setelah " +
            SimpleDateFormat("HH:mm", Locale.US).format(Date(until)) + "."

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* dikunci */ }
        })

        findViewById<Button>(R.id.btnOk).setOnClickListener {
            if (System.currentTimeMillis() >= until) finish() else moveTaskToBack(true)
        }
        h.post(tick)
    }

    override fun onResume() {
        super.onResume()
        if (System.currentTimeMillis() >= until) finish()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }
}
