package com.satpam.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * SATPAM - memantau aplikasi yang sedang dibuka 24 jam.
 * Setiap aplikasi yang masuk batas (halaman Fokus di aplikasi web)
 * dihitung waktu pemakaiannya; saat habis, pengguna ditendang keluar
 * (HOME) dan aplikasi dikunci sampai waktu buka lagi.
 */
class GuardService : AccessibilityService() {

    data class Limit(val app: String, val limitMin: Int, val lockMin: Int, val unlockTime: String)

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var currentPkg: String? = null
    private var lastEventAt: Long = 0L
    private val labelCache = HashMap<String, String>()

    private val ticker = object : Runnable {
        override fun run() {
            accumulate()
            currentPkg?.let { check(it) }
            handler.postDelayed(this, 5000)
        }
    }

    override fun onServiceConnected() {
        prefs = getSharedPreferences("satpam", MODE_PRIVATE)
        startForeground(1, notification())
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        accumulate()
        currentPkg = pkg
        check(pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    /* ---------- data ---------- */

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun limits(): List<Limit> {
        val out = mutableListOf<Limit>()
        try {
            val arr = JSONArray(prefs.getString("limits", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Limit(
                        o.optString("app"),
                        o.optInt("limit", 0),
                        o.optInt("lockMin", 0),
                        o.optString("unlockTime", "")
                    )
                )
            }
        } catch (_: Exception) { }
        return out.filter { it.app.isNotBlank() && it.limitMin > 0 }
    }

    private fun labelOf(pkg: String): String =
        labelCache.getOrPut(pkg) {
            try {
                val pm: PackageManager = packageManager
                val info = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(info).toString()
            } catch (_: Exception) { pkg }
        }

    /** cocokkan nama batas dengan label aplikasi */
    private fun findLimit(pkg: String): Limit? {
        if (limits().any { it.app.equals(pkg, true) }) {
            return limits().first { it.app.equals(pkg, true) }
        }
        val label = labelOf(pkg).lowercase(Locale.US)
        return limits().firstOrNull {
            val n = it.app.lowercase(Locale.US)
            label.contains(n) || (n.contains(label) && label.length >= 3)
        }
    }

    private fun usageKey(l: Limit) = "usage_" + l.app.lowercase(Locale.US)
    private fun lockKey(l: Limit) = "lock_" + l.app.lowercase(Locale.US)

    private fun usageSec(l: Limit): Int {
        val raw = prefs.getString(usageKey(l), "") ?: return 0
        val parts = raw.split(":")
        if (parts.size != 2 || parts[0] != today()) return 0
        return parts[1].toIntOrNull() ?: 0
    }

    private fun addUsage(pkg: String, sec: Int) {
        val l = findLimit(pkg) ?: return
        val key = usageKey(l)
        val parts = (prefs.getString(key, "") ?: "").split(":")
        val cur = if (parts.size == 2 && parts[0] == today()) parts[1].toIntOrNull() ?: 0 else 0
        prefs.edit().putString(key, today() + ":" + (cur + sec)).apply()
    }

    private fun accumulate() {
        val now = System.currentTimeMillis()
        val pkg = currentPkg
        if (pkg != null && lastEventAt > 0) {
            val delta = ((now - lastEventAt) / 1000).toInt()
            if (delta in 1..120) addUsage(pkg, delta)
        }
        lastEventAt = now
    }

    /* ---------- logika satpam ---------- */

    private fun check(pkg: String) {
        if (pkg == packageName) return
        val l = findLimit(pkg) ?: return
        val now = System.currentTimeMillis()
        val until = prefs.getLong(lockKey(l), 0L)

        if (until > now) {                 // masih terkunci -> tendang keluar
            kickOut(l, until)
            return
        }
        if (until in 1..now) {             // kunci habis -> reset kuota harian
            prefs.edit().remove(lockKey(l)).putString(usageKey(l), today() + ":0").apply()
        }
        if (usageSec(l) >= l.limitMin * 60) {
            lock(l, now)
            kickOut(l, prefs.getLong(lockKey(l), now))
        }
    }

    private fun lock(l: Limit, now: Long) {
        val cal = Calendar.getInstance()
        var until: Long
        if (l.unlockTime.isNotBlank()) {
            val (h, m) = l.unlockTime.split(":").map { it.toInt() }
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, m)
            cal.set(Calendar.SECOND, 0)
            until = cal.timeInMillis
            if (until <= now) { cal.add(Calendar.DAY_OF_YEAR, 1); until = cal.timeInMillis }
        } else {
            until = now + l.lockMin * 60_000L
        }
        prefs.edit().putLong(lockKey(l), until).apply()
    }

    private fun kickOut(l: Limit, until: Long) {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createOneShot(500, 200))
        } catch (_: Exception) { }
        performGlobalAction(GLOBAL_ACTION_HOME)
        val i = Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("app", l.app)
            .putExtra("until", until)
        startActivity(i)
    }

    private fun notification(): Notification {
        val ch = "satpam"
        getSystemService(NotificationManager::class.java)
            ?.createNotificationChannel(NotificationChannel(ch, "Satpam aktif", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, ch)
            .setContentTitle("Satpam aktif")
            .setContentText("Memantau pemakaian aplikasi 24 jam.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
