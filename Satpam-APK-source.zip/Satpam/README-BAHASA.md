# SATPAM - Quest Life (APK Android)

APK pembungkus aplikasi web "Quest Life" dengan **satpam pemantau otomatis 24 jam**:
tanpa perlu menekan tombol "Mulai pakai", aplikasi yang melewati batas waktu
otomatis ditendang keluar (kembali ke layar utama) dan dikunci sampai
waktu buka lagi / durasi kunci selesai.

## Cara membangun APK
1. Install Android Studio (gratis).
2. Extract zip ini, buka folder `Satpam` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Build > Build Bundle(s)/APK(s) > Build APK(s). APK ada di `app/build/outputs/apk/release/`.

## Setup di HP (wajib, sekali saja)
Setelah install APK, tekan tombol di bawah layar sesuai urutan:
1. **Aksesibilitas** -> aktifkan "Satpam - Quest Life". Ini yang membuat satpam bisa
   melihat aplikasi yang sedang dibuka dan menendang kamu keluar.
2. **Pemakaian** -> izinkan akses data pemakaian (cadangan agar akurat).
3. **Baterai** -> bebaskan dari optimasi baterai agar satpam tidak dimatikan sistem.

Akan muncul notifikasi persisten "Satpam aktif" - itu tanda satpam bekerja 24 jam.

## Cara pakai
1. Buka aplikasi, masuk tab **Fokus**.
2. Isi nama aplikasi (mis. TikTok), batas menit, kunci selama / jam buka lagi, lalu Simpan.
3. Selesai. Main TikTok 30 menit tanpa sadar 1 jam? Satpam akan keluarkan kamu
   dan mengunci TikTok sesuai aturan yang kamu buat. Kuota direset setelah kunci habis.

## Catatan
- Nama aplikasi dicocokkan dengan nama tampilan aplikasi (tidak peka huruf besar/kecil).
- Hindari nama yang terlalu pendek (kurang dari 3 huruf) karena bisa tertukar.
- Alarm & pengingat tetap bekerja saat aplikasi terbuka, seperti versi web.
- Statistik pemakaian di tab Statistik ikut membaca data satpam.
